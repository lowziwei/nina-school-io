# Problem Set 2: Market Entry and Static Games

**Assigned:** Beginning of Week 6  
**Due:** End of Week 7 (Friday)  
**Weight:** 15% of course grade

**Instructions:** Show all derivations. Interpret estimates in plain English. Use Stata for empirical parts. Submit as PDF.

---

## Part A: Theory of Entry (30 points)

### A1. The Bresnahan-Reiss Framework (20 points)

Consider a market where $N$ identical firms compete. Firm profits when there are $N$ competitors in the market are:

$$\pi(N, S, \theta) = S \cdot V(N, \theta_d) - F(N, \theta_f)$$

where $S$ is market size, $V(N, \theta_d)$ is variable profit per consumer (decreasing in $N$), and $F(N, \theta_f)$ is fixed costs of entry.

**(a)** Define the entry threshold $s_N$: the minimum market size for which $N$ firms can profitably operate. Write the condition that defines $s_N$.

**(b)** Bresnahan & Reiss (1991) define the entry threshold ratio:
$$\lambda_N = s_N / s_1$$

Explain what $\lambda_N > N$ would imply about the intensity of competition as $N$ increases. What does $\lambda_N = N$ imply?

**(c)** Bresnahan & Reiss find that $\lambda_2 > 2$ but that $\lambda_N / N$ stabilizes for $N \geq 3$. Interpret this empirical finding. What does it imply about the competitive effects of entry?

**(d)** Suppose variable profits are $V(N) = \theta_0 - \theta_1 \ln(N)$. What value of $\theta_1$ implies that the market quickly becomes competitive with entry?

### A2. Ordered Probit (10 points)

Let the number of firms in a market be determined by:

$$N^* = S\theta_d - F\theta_f + \epsilon, \quad \epsilon \sim N(0, 1)$$

We observe $N = n$ when $\tau_{n-1} < N^* \leq \tau_n$, where $\tau_0 = -\infty < \tau_1 < \tau_2 < \ldots < \tau_{\bar{N}} = \infty$.

**(a)** Write the likelihood contribution for market $m$ with $n_m$ firms observed.

**(b)** How do we identify the competitive effect of entry ($\theta_d$) separately from fixed costs ($\theta_f$)?

**(c)** What is the key identifying assumption? What variation in the data identifies the model?

---

## Part B: Empirical Entry Estimation (55 points)

You are provided with `dental_markets.dta` (based loosely on Bresnahan & Reiss 1991 structure) containing:
- `nfirms`: number of dentists in town
- `pop`: town population
- `income`: median household income
- `distance`: distance to nearest large city
- `elderly_share`: share of population over 65

### B1. Descriptive Analysis (10 points)

**(a)** Tabulate the distribution of `nfirms` across markets. What fraction of markets have 0, 1, 2, 3, 4, 5+ firms?

**(b)** Plot the mean and median of `pop` by `nfirms`. Is there a positive relationship?

**(c)** Compute per-capita town size (population / firms) for towns with 1, 2, 3, 4, and 5 firms. Do these ratios increase with $N$?

### B2. Ordered Probit Estimation (25 points)

**(a)** Estimate an ordered probit model of the number of firms, treating markets with 5+ firms as the top category. Use `pop`, `income`, `distance`, and `elderly_share` as regressors.

```stata
oprobit nfirms pop income distance elderly_share
```

Report coefficient estimates and discuss signs.

**(b)** Report the predicted probability of $N=0, 1, 2, 3, 4, 5+$ firms for a town at the median of all covariates.

**(c)** Compute the marginal effect of a 10% increase in population on the probability of having 3+ firms.

**(d)** Test whether `income` and `elderly_share` are jointly significant. Interpret.

### B3. Entry Threshold Estimation (20 points)

Following Bresnahan & Reiss (1991), we estimate entry thresholds as the town sizes at which the transition from $N-1$ to $N$ firms occurs.

**(a)** Compute the average population of markets with exactly $N$ firms, for $N = 1, 2, 3, 4, 5$.

**(b)** Estimate the entry threshold $\hat{s}_N$ as the population at which the predicted probability of $N$ or more firms equals 0.5. Report $\hat{s}_N$ for $N = 1, \ldots, 5$.

**(c)** Compute the threshold ratios $\hat{\lambda}_N = \hat{s}_N / \hat{s}_1$. Compare to $N$. Does competition intensify with entry?

**(d)** Bootstrap standard errors for $\hat{\lambda}_N$ using 500 replications.

```stata
* Hint: use bootstrap, reps(500): to bootstrap any estimation
bootstrap lambda2 = r(lambda2), reps(500): /* your estimation command */
```

---

## Part C: Counterfactuals & Policy (15 points)

### C1. Effect of Regulation

Suppose a regulation increases the fixed cost of entry by 20% (i.e., it becomes 20% more expensive to open a dental practice).

**(a)** In the Bresnahan-Reiss framework, how does this affect the threshold $s_N$? Show the comparative static.

**(b)** Using your ordered probit estimates, predict the effect on the number of markets with 0 vs. 1+ dentists. (Assume the fixed cost is captured in the constant term.)

**(c)** Who bears the welfare cost of this regulation — consumers or producers? How would you measure consumer welfare loss in this framework?

### C2. Reflection

**(a)** The Bresnahan-Reiss model assumes firms are homogeneous. Seim (2006) relaxes this. What identification challenges arise with heterogeneous firms?

**(b)** In a real antitrust case involving a proposed hospital merger, how would you use an entry model? What are the limits of the approach?

---

## Stata Starter Code

```stata
* Problem Set 2 - Market Entry
use "dental_markets.dta", clear

* ---- PART B1: Descriptives ----
tab nfirms
bysort nfirms: sum pop, detail
gen percapita_pop = pop / max(nfirms, 1)
table nfirms, contents(mean percapita_pop)

* ---- PART B2: Ordered Probit ----
* Cap at 5+
gen nfirms_cat = min(nfirms, 5)
oprobit nfirms_cat pop income distance elderly_share
margins, at(pop = (median) income = (median) distance = (median) elderly_share = (median))

* ---- PART B3: Thresholds ----
* Predict probabilities
predict p0 p1 p2 p3 p4 p5, pr
gen p_3plus = 1 - p0 - p1 - p2

* Find threshold s_N: pop at which P(N+ firms) = 0.5
* (fill in — requires some algebra or grid search over pop values)
```
