# Practice Final Exam

**Time limit:** 2 hours (simulate closed-book conditions)  
**Instructions:** Answer all three questions. Each is worth 33 points. No notes, no internet.

---

## Question 1: Demand Estimation (33 points)

A researcher wants to estimate demand for health insurance plans in the ACA Marketplace. There are $J$ plans in each market, differing in premiums $p_j$, deductibles $d_j$, and network breadth $n_j$. She has data on market shares $s_{jm}$ across 200 county-level markets.

**(a)** (6 pts) Write the logit demand model for this setting. Define all notation. What is the "outside option" here? Is it plausible?

**(b)** (6 pts) The researcher wants to instrument for premiums. Suggest two instruments and justify the exclusion restriction for each.

**(c)** (8 pts) She worries that consumers vary in their preference for low deductibles — sicker consumers value low deductibles more. How does the BLP random coefficients model accommodate this? Write the model formally and explain how $\Sigma$ (the covariance matrix of random coefficients) is identified.

**(d)** (7 pts) The researcher runs the BLP contraction mapping. Explain in words what the contraction mapping does and why it is needed. When might it fail to converge?

**(e)** (6 pts) After estimation, she finds that own-price elasticities for bronze plans are −1.8 and for platinum plans are −0.9. Interpret these numbers. Is it plausible that platinum plans are less price-elastic than bronze plans? Why or why not?

---

## Question 2: Static Entry (33 points)

A state government is considering permitting a new retail pharmacy chain to enter 300 small towns, some of which currently have 0, 1, or 2 pharmacies.

**(a)** (8 pts) Describe the Bresnahan & Reiss (1991) ordered probit entry model. What is the key estimating equation? What variation in the data identifies competitive effects?

**(b)** (6 pts) The researcher estimates threshold ratios $\hat{\lambda}_2 / 2 = 1.4$ and $\hat{\lambda}_3 / 3 = 1.02$. Interpret these numbers. What do they say about how competitive markets with 2 vs. 3 pharmacies are?

**(c)** (7 pts) The government wants to know: if the chain enters, how many towns will go from monopoly to duopoly? What additional information do you need beyond the estimated threshold ratios?

**(d)** (6 pts) A colleague suggests using Seim (2006) instead of Bresnahan-Reiss because pharmacies differentiate by location. What does Seim (2006) add? What is the additional identification challenge?

**(e)** (6 pts) Name one assumption in the static entry framework that you find most problematic for the pharmacy application. How would you test or relax it?

---

## Question 3: Dynamic Models (33 points)

Consider a market for 4G mobile spectrum licenses. Carriers decide each period whether to hold, acquire, or divest licenses. You want to estimate a dynamic model of this market.

**(a)** (8 pts) Write down the single-agent dynamic discrete choice model (in the spirit of Rust 1987) for a single carrier's license acquisition decision. Define the state space, choice set, and flow utilities. What is the Bellman equation?

**(b)** (7 pts) Explain the Hotz-Miller (1993) CCP approach. What is the key insight that allows estimation without solving the full dynamic program? What data objects do you need?

**(c)** (8 pts) Now suppose carriers' strategies are interdependent — acquiring a license blocks a competitor. You want to estimate a dynamic oligopoly model. Describe the Bajari, Benkard & Levin (2007) two-step estimator. What does each step estimate? What equilibrium concept does it impose?

**(d)** (5 pts) What is the "curse of dimensionality" in dynamic games? Why is it a problem in the spectrum setting?

**(e)** (5 pts) An empiricist finds that the BBL estimates suggest very high discount factors ($\beta \approx 0.99$). A critic says the model is not identified. What identification concern is the critic raising? How might you address it?

---

## Self-Grading Guide

After completing, check your answers against these benchmarks:

**Q1 benchmarks:**
- (a) Must define: $s_{jm} = \exp(\delta_{jm}) / [1 + \sum_k \exp(\delta_{km})]$, outside option = uninsured or employer coverage
- (b) Hausman instruments (cross-market price variation) and cost-shifters (insurer administrative costs, network hospital prices)
- (c) Individual $i$ has coefficient $\alpha_i = \bar{\alpha} + \sigma_\alpha \nu_i$; $\Sigma$ identified from micro data or by exploiting market-level variation in demographics
- (d) Contraction: given $\theta$, find $\delta$ such that predicted shares match observed shares; fails if shares are very small (near-zero) or BLP instruments are weak

**Q2 benchmarks:**
- (a) Key equation: $P(N \geq n | S, X) = \Phi(S\theta_d - F\theta_f - \tau_{n-1})$; identification from cross-market variation in size $S$ holding $X$ fixed
- (b) $\lambda_2/2 = 1.4$: a duopoly market needs 40% more consumers than two monopoly markets — competition reduces profits. $\lambda_3/3 \approx 1$: markets with 3+ firms behave competitively.

**Q3 benchmarks:**
- (a) $V(a,s) = u(a,s) + \beta \mathbb{E}[V(a',s') | a,s]$; state includes license holdings, competitor states, demand shocks
- (b) CCPs $P(a|s)$ can be estimated nonparametrically; future value terms expressed as function of CCPs and flow utilities — no need to solve fixed point
- (c) Step 1: estimate CCPs and simulate forward to get expected payoffs; Step 2: use moment inequalities / GMM to recover structural parameters; imposes MPE
