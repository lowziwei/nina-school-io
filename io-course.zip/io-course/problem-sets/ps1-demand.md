# Problem Set 1: Demand Estimation for Differentiated Products

**Assigned:** End of Week 3  
**Due:** End of Week 4 (Saturday)  
**Weight:** 15% of course grade (in the ECO310 structure)

**Instructions:** All answers should be typed. Show all derivations and interpret all estimates economically. Use Stata (or pyBLP for parts marked *optional*). Submit as PDF.

---

## Part A: Theoretical Foundations (25 points)

### A1. The IIA Problem (10 points)

Consider a market with three products: a Honda Civic (product 1), a Toyota Corolla (product 2), and a BMW 3-series (product 3), plus an outside option (product 0).

Under the standard logit model, market shares are:

$$s_j = \frac{\exp(\delta_j)}{1 + \sum_{k=1}^{J} \exp(\delta_k)}$$

where $\delta_j = \alpha p_j + x_j'\beta + \xi_j$.

**(a)** Write the own-price and cross-price elasticity formulas for the logit model.

**(b)** Suppose the BMW is removed from the market. Using the IIA property, calculate how demand for the Civic and Corolla changes. Comment on whether this is economically plausible.

**(c)** Explain intuitively why the random coefficients model (BLP) solves the IIA problem. What is the key ingredient?

### A2. Berry (1994) Inversion (15 points)

**(a)** Starting from the logit market share formula, derive the Berry (1994) inversion:
$$\ln(s_j) - \ln(s_0) = \delta_j$$

**(b)** Explain why this inversion is useful for estimation. What did it enable that was not possible before?

**(c)** Write down the endogeneity problem in OLS estimation of $\delta_j = \alpha p_j + x_j'\beta + \xi_j$. Why is price endogenous? Give two examples of valid instruments.

**(d)** Define the BLP (1995) instruments. Are they valid? What is the exclusion restriction?

---

## Part B: Empirical Estimation (60 points)

You are provided with a dataset `cereal_data.dta` containing:
- `market`: market identifier (city-quarter)
- `product`: product identifier
- `share`: market share $s_j$
- `price`: product price
- `sugar`: sugar content (grams per serving)
- `mushy`: indicator for mushy cereal
- `income_mean`: mean household income in market
- `num_products`: number of products in market

This dataset is loosely based on Nevo (2001).

### B1. Simple Logit (20 points)

**(a)** Construct the logit dependent variable $y_j = \ln(s_j) - \ln(s_0)$ in Stata. How do you compute $s_0$ (outside good share)? Assume the total potential market size is 2 servings per person per day × market population.

**(b)** Estimate by OLS:
$$y_{jm} = \alpha p_{jm} + \beta_1 \text{sugar}_j + \beta_2 \text{mushy}_j + \xi_{jm}$$

Report coefficient estimates, standard errors (clustered at the market level), and $R^2$.

**(c)** Interpret the price coefficient $\hat{\alpha}$. Is the sign correct? Compute the implied own-price elasticity at the mean market share.

**(d)** Now instrument for price using: (i) the mean price of the same product in other markets (Hausman instrument), and (ii) the number of products in the market. Report first-stage $F$-statistics and discuss instrument validity.

**(e)** Compare OLS and IV estimates of $\alpha$. Which direction does the bias go? Explain.

### B2. Nested Logit (20 points)

Suppose products are grouped into two nests: $g=1$ (healthy cereals, sugar < 8g) and $g=2$ (regular cereals).

**(a)** Write the nested logit share equation and the resulting estimating equation (Berry 1994 inversion for nested logit includes $\sigma \ln(s_{j|g})$ where $\sigma \in [0,1]$ is the within-group correlation parameter).

**(b)** Estimate the nested logit by IV (instrument for both price and within-group share). Report results.

**(c)** Test $H_0: \sigma = 0$ (simple logit). Interpret $\hat{\sigma}$.

**(d)** Compute own-price and cross-price elasticities. Do the nested logit results seem more plausible than simple logit?

### B3. Supply Side & Markups (20 points)

Assume Nash-Bertrand competition. Under profit maximization, each firm $f$ sets prices to satisfy:

$$p_j = mc_j - \left(\Omega^{-1}(s)\right)_j$$

where $\Omega_{jk} = -\partial s_j / \partial p_k$ if $j$ and $k$ are owned by the same firm, and 0 otherwise.

**(a)** Using your logit demand estimates, compute the ownership matrix $\Omega$ (assume each product is owned by a separate firm, for simplicity).

**(b)** Back out implied marginal costs $\hat{mc}_j = p_j + \left(\Omega^{-1}s\right)_j$.

**(c)** Compute the Lerner index $L_j = (p_j - \hat{mc}_j)/p_j$ for each product. Report summary statistics.

**(d)** Do your estimated markups seem reasonable given what you know about the cereal industry?

---

## Part C: Interpretation & Welfare (15 points)

### C1. Merger Simulation

Suppose Post (which owns Raisin Bran and Grape Nuts) merges with Kellogg's (which owns Frosted Flakes and Rice Krispies).

**(a)** Using your demand and supply estimates, compute the post-merger Nash-Bertrand equilibrium prices. (You will need to update the ownership matrix.)

**(b)** Compute the price increase for each product. Are they large?

**(c)** Compute consumer surplus under pre- and post-merger prices using the logit formula:
$$CS = \frac{1}{\alpha} \ln\left(1 + \sum_j \exp(\delta_j)\right)$$

Report the change in consumer surplus per market.

### C2. Reflection

**(a)** What are the three most important assumptions you made in this problem set? Which do you find most worrisome?

**(b)** If you could add one feature to the demand model to improve it, what would it be and why?

---

## Stata Starter Code

```stata
* Problem Set 1 - Demand Estimation
* Load data
use "cereal_data.dta", clear

* ---- PART B1: Simple Logit ----

* Construct outside share (adjust market_size to your calculation)
bysort market: gen total_share = sum(share)
gen s0 = 1 - total_share
gen y = ln(share) - ln(s0)

* OLS
reg y price sugar mushy, cluster(market)

* Hausman instrument: mean price in other markets
bysort product: egen mean_price_other = mean(price)
replace mean_price_other = (mean_price_other * _N - price) / (_N - 1)

* IV with Hausman instrument
ivregress 2sls y sugar mushy (price = mean_price_other num_products), cluster(market) first

* ---- PART B2: Nested Logit ----

* Within-group share
bysort market nest: gen share_nest = sum(share)
gen s_jg = share / share_nest
gen ln_s_jg = ln(s_jg)

* Nested logit IV
ivregress 2sls y sugar mushy (price ln_s_jg = mean_price_other num_products /*
    add more instruments here */), cluster(market) first

* ---- PART B3: Elasticities ----
* (fill in after estimation)
```

---

*Hint: For Part B3, the own-price elasticity in the simple logit is $\eta_{jj} = \alpha p_j (1 - s_j)$ and cross-price elasticity is $\eta_{jk} = -\alpha p_k s_k$.*
