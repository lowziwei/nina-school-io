# Stata Reference Guide for Empirical IO

A practical reference covering the Stata commands most commonly used in this course.

---

## Setup

```stata
* Always start a do-file with:
clear all
set more off
capture log close
log using "output/log_filename.log", replace

* Set working directory
cd "/path/to/your/project"
```

---

## Data Management

```stata
* Load data
use "data/filename.dta", clear
import delimited "data/filename.csv", clear

* Inspect
describe
summarize
codebook
list in 1/10

* Panel setup (for markets × products)
xtset market product

* Sort and by-groups
sort market product
bysort market: gen rank = _n

* Generate variables
gen log_price = ln(price)
gen price_sq = price^2
replace var = 0 if missing(var)

* Label
label var price "Product price (USD)"
label define nfirms_lbl 0 "No firms" 1 "Monopoly" 2 "Duopoly"
label values nfirms nfirms_lbl
```

---

## Week 1–2: Basic Regression & IV

```stata
* OLS
reg y x1 x2 x3
reg y x1 x2 x3, robust
reg y x1 x2 x3, cluster(market_id)

* IV / 2SLS
ivregress 2sls y x1 x2 (endogenous_var = instrument1 instrument2), cluster(market_id)
* First stage:
ivregress 2sls y x1 x2 (endogenous_var = z1 z2), first cluster(market_id)

* Test instrument strength
estat firststage   // after ivregress
* Rule of thumb: F > 10 for single instrument; use Kleibergen-Paap for multiple

* Overidentification test (Hansen J)
estat overid   // after ivregress with more instruments than endogenous vars

* Fixed effects
areg y x1 x2, absorb(market_id) cluster(market_id)
* Or:
reghdfe y x1 x2, absorb(market_id product_id) cluster(market_id)  // requires ssc install reghdfe
```

---

## Week 2: Production Function Estimation

```stata
* Install prodest package (Olley-Pakes, Levinsohn-Petrin, ACF)
ssc install prodest

* Levinsohn-Petrin estimator
prodest lnY, free(lnL) proxy(lnM) state(lnK) va

* Olley-Pakes estimator (requires investment data)
prodest lnY, free(lnL) proxy(lnI) state(lnK) opt(opmethod(OP))

* ACF correction
prodest lnY, free(lnL) proxy(lnM) state(lnK) opt(acf)

* Output TFP residuals
predict tfp, residuals
```

---

## Week 3–5: Demand Estimation

### Logit Demand (Berry 1994)

```stata
* Step 1: Compute market shares
* (Assume you have share_j and market_size)
bysort market: gen total_share = sum(share)
gen s0 = 1 - total_share
gen y = ln(share) - ln(s0)   // Berry inversion

* Step 2: OLS (biased — for comparison only)
reg y price x1 x2, cluster(market)

* Step 3: Construct Hausman instruments
* Mean price in other markets (requires panel structure)
bysort product: egen price_mean = mean(price)
bysort product: gen N_markets = _N
gen hausman_iv = (price_mean * N_markets - price) / (N_markets - 1)

* Step 4: IV estimation
ivregress 2sls y x1 x2 (price = hausman_iv cost_iv), cluster(market) first

* Step 5: Own-price elasticity (logit)
* eta_jj = alpha * price_j * (1 - s_j)
gen alpha = [coefficient on price from IV]
gen own_elas = alpha * price * (1 - share)
sum own_elas, detail
```

### Nested Logit

```stata
* Within-group share
bysort market nest_group: gen group_share = sum(share)
gen s_jg = share / group_share
gen ln_s_jg = ln(s_jg)

* Nested logit IV (instrument for both price and within-group share)
ivregress 2sls y x1 x2 (price ln_s_jg = hausman_iv cost_iv group_iv), ///
    cluster(market) first

* Test sigma = 0: test the coefficient on ln_s_jg
test ln_s_jg = 0
```

### Supply Side / Markup Recovery

```stata
* After estimating alpha from demand:
* Under logit Nash-Bertrand with single-product firms:
* markup_j = -1 / (alpha * (1 - s_j))
gen markup = -1 / (alpha_est * (1 - share))
gen marginal_cost = price - markup
gen lerner = markup / price

sum lerner, detail
```

---

## Week 6: Entry Models

```stata
* Ordered probit
oprobit nfirms pop income distance controls

* Predict probabilities
predict p0 p1 p2 p3, pr

* Marginal effects at mean
margins, dydx(*) atmeans

* Marginal effect of population on P(N >= 3)
gen p3plus = 1 - p0 - p1 - p2
margins, dydx(pop) atmeans expression(1 - predict(outcome(0)) ///
    - predict(outcome(1)) - predict(outcome(2)))

* Probit (binary: any firm vs none)
probit entry pop income controls
margins, dydx(*) atmeans

* Bootstrap standard errors
bootstrap r(mean): sum lerner   // example
bootstrap _b, reps(500) seed(42): oprobit nfirms pop income distance
```

---

## Useful Utility Commands

```stata
* Tables
tabstat var1 var2 var3, by(nfirms) stats(mean sd p50 n)
table nfirms, contents(mean share mean price)

* Graphs
histogram price, by(nfirms) normal
scatter y price, mcolor(blue%50) || lfit y price
graph export "output/figure1.png", replace

* Correlations
pwcorr price cost_iv hausman_iv, sig

* Missing values
misstable summarize
drop if missing(price) | missing(share)

* Collapse to market level
collapse (mean) price share (sum) revenue, by(market year)

* Merge datasets
merge 1:1 market product using "data/instruments.dta"
* Check: assert _merge == 3   // all matched
drop _merge

* Reshape
reshape wide share price, i(market) j(product)
reshape long share price, i(market) j(product)

* Winsorize
winsor2 price, cuts(1 99) replace   // requires ssc install winsor2
```

---

## Packages to Install

```stata
ssc install ivreg2        // extended IV with robust/cluster options
ssc install ranktest      // Kleibergen-Paap weak IV test
ssc install estout        // formatted regression tables
ssc install prodest       // production function estimation (OP, LP, ACF)
ssc install reghdfe       // high-dimensional fixed effects
ssc install ftools        // fast collapse/merge (required by reghdfe)
ssc install winsor2       // winsorizing
ssc install coefplot      // coefficient plots
net install pyblp         // pyBLP Stata bridge (if available)
```

---

## Output Tables with `estout`

```stata
* Store estimates
eststo m1: reg y price x1, cluster(market)
eststo m2: ivregress 2sls y x1 (price = iv1), cluster(market)
eststo m3: ivregress 2sls y x1 (price = iv1 iv2), cluster(market)

* Export
esttab m1 m2 m3 using "output/table1.tex", ///
    b(3) se(3) star(* 0.10 ** 0.05 *** 0.01) ///
    label title("Demand Estimation Results") ///
    mtitles("OLS" "IV (1)" "IV (2)") replace

* Or to screen
esttab m1 m2 m3, b(3) se(3) star(* 0.10 ** 0.05 *** 0.01)
```
