# Math & Econometrics Prerequisites Review

A self-assessment and reference guide. If any section feels unfamiliar, spend extra time there before starting the corresponding week.

---

## 1. Linear Algebra Essentials

### Matrix notation (used throughout)
- $X$ is an $N \times K$ matrix of regressors
- $\beta$ is a $K \times 1$ parameter vector
- $\hat{\beta}_{OLS} = (X'X)^{-1}X'y$

### Concepts you should know
- Matrix multiplication, transpose, inverse
- Positive definiteness (relevant for covariance matrices)
- Eigenvalues (relevant for GMM weighting matrices)

**Self-test:** Show that $\hat{\beta}_{OLS}$ minimizes $\sum_i (y_i - x_i'\beta)^2$.

---

## 2. Probability & Distributions

### Key distributions in IO
- **Normal:** $\epsilon \sim N(0, \sigma^2)$ — used in probit, BLP unobservables
- **Logistic:** $F(x) = e^x / (1 + e^x)$ — used in logit demand
- **Gumbel (Type I Extreme Value):** used to derive logit market share formula

### The logit formula derivation
Suppose utility is $u_{ij} = \delta_j + \epsilon_{ij}$ where $\epsilon_{ij}$ is i.i.d. Type I Extreme Value.

Then:
$$P(\text{consumer } i \text{ chooses } j) = \frac{e^{\delta_j}}{\sum_k e^{\delta_k}}$$

**Self-test:** Verify this by integrating $P(u_{ij} > u_{ik} \; \forall k \neq j)$ using the GEV CDF.

---

## 3. Econometrics: OLS

### The classical linear model
$$y = X\beta + \epsilon, \quad \mathbb{E}[\epsilon | X] = 0$$

### OLS assumptions and when they fail
| Assumption | Violation | Consequence |
|-----------|-----------|-------------|
| $\mathbb{E}[\epsilon_i | X_i] = 0$ | Endogeneity | Biased, inconsistent |
| $\text{Var}(\epsilon_i | X_i) = \sigma^2$ | Heteroskedasticity | Inefficient, wrong SEs |
| $\text{Cov}(\epsilon_i, \epsilon_j) = 0$ | Clustering | Wrong SEs |
| $X_i$ non-stochastic | Measurement error | Attenuation bias |

### Omitted variable bias formula
If the true model is $y = X_1\beta_1 + X_2\beta_2 + \epsilon$ but you estimate without $X_2$:
$$\text{plim}(\hat{\beta}_1^{OLS}) = \beta_1 + \underbrace{(X_1'X_1)^{-1}X_1'X_2}_{\text{auxiliary regression}} \beta_2$$

**Self-test:** In demand estimation, explain the direction of OLS price coefficient bias using this formula. (Hint: $\xi_j$ is the omitted variable.)

---

## 4. Instrumental Variables

### The IV estimator
$$\hat{\beta}_{IV} = (Z'X)^{-1}Z'y$$

where $Z$ are instruments satisfying:
1. **Relevance:** $\text{Cov}(Z, X) \neq 0$ (testable: F-test in first stage)
2. **Exclusion:** $\text{Cov}(Z, \epsilon) = 0$ (not directly testable — requires economic argument)

### 2SLS (two-stage least squares)
- Stage 1: Regress $X$ on $Z$, get $\hat{X}$
- Stage 2: Regress $y$ on $\hat{X}$

### Weak instruments
- When $\text{Corr}(Z, X)$ is small, IV is biased toward OLS
- Rule of thumb: first-stage $F > 10$ (single instrument)
- For multiple instruments, use Kleibergen-Paap rk statistic

### Hausman test
Tests $H_0: \beta_{OLS} = \beta_{IV}$ (i.e., OLS is consistent).
- Reject → endogeneity confirmed, use IV
- Fail to reject → either no endogeneity, or instruments are weak

**Self-test:** In Genesove & Mullin (1998), what is the instrument for sugar price? Does it satisfy the exclusion restriction?

---

## 5. Maximum Likelihood Estimation

### The likelihood function
Given data $\{y_i\}_{i=1}^N$ and model $f(y_i; \theta)$:
$$\mathcal{L}(\theta) = \prod_{i=1}^N f(y_i; \theta)$$

In practice, maximize the log-likelihood:
$$\ell(\theta) = \sum_{i=1}^N \ln f(y_i; \theta)$$

### Probit MLE
$$P(y_i = 1 | x_i) = \Phi(x_i'\beta)$$
$$\ell(\beta) = \sum_i \left[y_i \ln \Phi(x_i'\beta) + (1-y_i) \ln(1-\Phi(x_i'\beta))\right]$$

### Ordered probit (used in entry models)
$$P(y_i = j | x_i) = \Phi(\tau_j - x_i'\beta) - \Phi(\tau_{j-1} - x_i'\beta)$$

**Self-test:** Write the ordered probit likelihood for a market with $N = 2$ firms observed.

---

## 6. GMM (Generalized Method of Moments)

### The GMM estimator
Given moment conditions $\mathbb{E}[g(y_i, \theta)] = 0$:
$$\hat{\theta}_{GMM} = \arg\min_\theta \; \bar{g}(\theta)' W \bar{g}(\theta)$$

where $\bar{g}(\theta) = \frac{1}{N}\sum_i g(y_i, \theta)$ and $W$ is a weighting matrix.

### Efficient GMM
Use $W = \left[\text{Var}(g(y_i, \theta))\right]^{-1}$ (the efficient weighting matrix).

### IV as GMM
The IV estimator is GMM with $g(y_i, \beta) = Z_i(y_i - X_i'\beta)$.

### BLP as GMM
BLP (1995) uses:
$$g(\theta) = Z'\xi(\theta)$$
where $\xi(\theta) = \delta(\theta) - X\beta - \alpha p$ are demand unobservables backed out from the share inversion.

**Self-test:** What are the moment conditions in BLP (1995)? Why does GMM require instruments for price?

---

## 7. Discrete Choice Models

### The utility framework
Consumer $i$ gets utility $u_{ij} = V(x_j, p_j, \nu_i; \theta) + \epsilon_{ij}$ from product $j$.

Consumer chooses $j^* = \arg\max_j u_{ij}$.

### Logit (i.i.d. Gumbel $\epsilon$)
$$s_j = \frac{e^{\delta_j}}{1 + \sum_k e^{\delta_k}}, \quad \delta_j = x_j'\beta - \alpha p_j + \xi_j$$

### Random coefficients logit (BLP)
$$u_{ij} = x_j'(\bar{\beta} + \Sigma \nu_i) - \bar{\alpha} p_j + \xi_j + \epsilon_{ij}$$

Market share requires integrating over individual heterogeneity $\nu_i \sim N(0, I)$:
$$s_j(\delta, \theta) = \int \frac{e^{\delta_j + \mu_{ij}}}{1 + \sum_k e^{\delta_k + \mu_{ik}}} dF(\nu)$$

Solved numerically via Monte Carlo or sparse grids.

### Welfare (consumer surplus)
Under logit:
$$CS = \frac{1}{\alpha} \ln\left(1 + \sum_j e^{\delta_j}\right) + \text{const}$$

---

## 8. Dynamic Programming Basics

### Bellman equation (finite horizon)
$$V_t(s) = \max_a \left[ u(a, s) + \beta \mathbb{E}[V_{t+1}(s') | a, s] \right]$$

### Bellman equation (infinite horizon, stationary)
$$V(s) = \max_a \left[ u(a, s) + \beta \sum_{s'} P(s' | a, s) V(s') \right]$$

### Value iteration algorithm
1. Start with $V^0(s) = 0$ for all $s$
2. Iterate: $V^{k+1}(s) = \max_a \left[u(a,s) + \beta \sum_{s'} P(s'|a,s) V^k(s')\right]$
3. Converge when $\|V^{k+1} - V^k\|_\infty < \epsilon$

### Rust (1987) key insight
With additive i.i.d. Type I Extreme Value $\epsilon$, the integrated value function has a closed form:
$$\bar{V}(s) = \log \sum_a \exp\left(u(a,s) + \beta \sum_{s'} P(s'|a,s) \bar{V}(s')\right) + \gamma$$

This is the logit smoothing trick that makes the NFXP tractable.

**Self-test:** Write the Bellman equation for Rust (1987). What is the state variable? What is the choice?

---

## Quick Self-Assessment Checklist

Before starting the course, confirm you can:

- [ ] Derive the OLS estimator using FOCs
- [ ] Explain omitted variable bias with a formula
- [ ] State the two conditions for a valid instrument
- [ ] Derive the logit market share formula from utility maximization
- [ ] Write the log-likelihood for a probit model
- [ ] Write a GMM objective function and explain the moment conditions
- [ ] Write the Bellman equation for a two-state, two-action dynamic problem

If 3+ boxes are unchecked, review Wooldridge (2008) Chapters 1–5 and 15–16 before Week 1.
